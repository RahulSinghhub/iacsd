package com.app.banking;

public enum AcType {
	SAVINGS, CURRENT, FD, LOAN, DMAT, NRE
}
